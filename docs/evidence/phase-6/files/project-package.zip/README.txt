Studio 2.0 project package: Untitled Project
Exported: 2026-10-27T08:26:22.369Z

Contents:
- project.json: the complete Studio project document.
- assets/: rendered artwork, source media, masks and BEND packages.
- source-states/: editable native documents for Image, Vector, Type, Shapes, Generate and BEND.
- manifest.json: package format/version, entry paths, SHA-256 hashes and limits.

Import this ZIP with Studio's Project menu. Studio validates every hash before
writing anything. It never overwrites an existing project with the same ID.

This is editable project state, not a flattened PNG export.
